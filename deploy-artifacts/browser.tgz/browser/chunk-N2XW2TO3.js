import{b as Ye,c as Je,g as Ui}from"./chunk-T5X7M7SV.js";import{T as ti,U as Vi,x as Ze,y as ji}from"./chunk-JZNGJDZI.js";import{g as Xe,h as zi}from"./chunk-B6YCO63Y.js";import{a as W,b as xt,c as We,d as qt,p as Ni}from"./chunk-MK5ELEVS.js";import{A as Be,U as kt,V as Ne,Xa as D,Ya as Ht,z as vt}from"./chunk-CBPIQ6DS.js";import{b as Qe,c as Bi}from"./chunk-PREQ37DS.js";import{a as Ke,b as Ri,c as $e,d as Pi}from"./chunk-WK7OQWG3.js";import{a as C,d as jt}from"./chunk-TFDE5GL7.js";import{V as ft,W as Fe,X as Pe,Y as Ai,a as zt,b as bi,g as Oe,o as yi}from"./chunk-R6OJFZTB.js";import{F as qe,O as Fi,y as He}from"./chunk-M4OYX3BO.js";import{$a as Ii,E as Ae,I as Le,Ia as xi,Jb as Ge,Ka as De,Lb as Ti,Ma as wi,Ta as P,Va as Si,Yb as N,Zb as Gt,_a as Me,d as _t,g as we,hb as Li,mb as yt,ob as ze,qb as Ue,r as Se,rb as je,tb as Di,u as vi,ub as Ve,vb as Mi,w as Ie,x as ki,y as Ee}from"./chunk-WZDQ5LU5.js";import{j as Te,k as Oi,l as Ci}from"./chunk-STHEZKHG.js";import{a as g,b as Ut}from"./chunk-VT4R4KFH.js";import{a as Q,d as Ce}from"./chunk-W2C4DBEJ.js";import{a as Bt,b as fi,c as B,e as Re}from"./chunk-XCP44WGM.js";import{a as A,c as xe,q as ut}from"./chunk-MW5MF2YD.js";import{a as bt,b as Ei}from"./chunk-YNJSQG7S.js";import{c as ye,d as gi}from"./chunk-C4N4CKT3.js";import{a as b,g as Nt,h as $}from"./chunk-7DBDLXYW.js";import{$c as R,Ca as At,Cb as ue,D as oe,Dc as Tt,E as se,Ea as m,Ec as K,F as it,Fc as lt,Gc as mt,Hb as Lt,K as ce,Od as ke,P as nt,Pa as he,Ra as rt,Tc as _e,Ua as pe,Ud as pt,Vc as dt,W as le,Wc as Ft,X as me,Xc as T,Ya as V,Yb as H,Yc as Rt,Zc as fe,_b as L,_c as F,a as ne,bb as ot,bc as q,ed as Pt,fb as G,fd as ht,hb as st,id as ge,ie as I,jd as be,l as j,ma as at,n as ae,pa as de,s as tt,t as re,ta as Et,u as et,uc as ct,wc as Dt,xd as ve,yc as Mt,za as E}from"./chunk-BYZBW3B6.js";import{a as gt,b as Vt}from"./chunk-UZGBAYMW.js";import{a as f,b as w,c as ie,d as Z,e as S,j as u}from"./chunk-PE6UJDCZ.js";function Gi(i){if(!isFinite(i))return 0;let s=1,t=0;for(;Math.round(i*s)/s!==i;)s*=10,t++;return t}function O(i){return i===""||i==null}function X(i){return i!=null&&typeof i=="object"&&!Array.isArray(i)}function Hi(i){return Number.isInteger?Number.isInteger(i):typeof i=="number"&&Math.floor(i)===i}function Kt(i){return typeof i=="object"&&(i.hasOwnProperty("const")||i.enum&&i.enum.length===1)}function qi(i){if(i===""||i===void 0)return;if(i===null)return null;if(typeof i=="number")return i;let s=parseFloat(i);return isNaN(s)?i:s}function wt(i){if(!i.fieldGroup)return W(i)&&xt(i)!==void 0?1:0;let s=i.fieldGroup.reduce((t,e)=>wt(e)+t,0);if(s===0&&W(i)){let t=xt(i);if(t===null||t!==void 0&&(i.fieldArray&&Array.isArray(t)||!i.fieldArray&&X(t)))return 1}return s}var jn,Ki=S(()=>{"use strict";I();Fi();Ni();ot();jn=(()=>{class i{toFieldConfig(t,e){return t=qt(t),this._toFieldConfig(t,f({schema:t},e||{}))}_toFieldConfig(t,c){var h=c,{key:e,isOptional:n}=h,a=Z(h,["key","isOptional"]);t=this.resolveSchema(t,a);let d=this.guessSchemaType(t),r={type:d[0],defaultValue:t.default,props:{label:t.title,readonly:t.readOnly,description:t.description}};if(e!=null&&(r.key=e),!a.ignoreDefault&&(t.readOnly||a.readOnly)&&(r.props.disabled=!0,a=w(f({},a),{readOnly:!0})),a.resetOnHide&&(r.resetOnHide=!0),a.shareFormControl===!1&&(r.shareFormControl=!1),r.defaultValue===void 0&&d.length===1&&n===!1)switch(d[0]){case"null":{r.defaultValue=null;break}case"string":{r.defaultValue="";break}case"object":{r.defaultValue={};break}case"array":{r.defaultValue=t.minItems>0?Array.from(new Array(t.minItems)):[];break}}switch(a.ignoreDefault&&delete r.defaultValue,this.addValidator(r,"type",{schemaType:d,expression:({value:o})=>{if(o===void 0||o===null&&d.indexOf("null")!==-1)return!0;switch(d[0]){case"null":return typeof o===null;case"string":return typeof o=="string";case"integer":return Hi(o);case"number":return typeof o=="number";case"object":return X(o);case"array":return Array.isArray(o)}return!0}}),r.type){case"number":case"integer":{r.parsers=[(o,p)=>{if(o=qi(o),o===null&&p){let l=typeof document<"u"&&p.id?document.querySelector(`#${p.id}`):void 0;l&&l.validity&&!l.validity.badInput&&(o=void 0),o!==p.formControl.value&&p.formControl.setValue(o,{emitModelToViewChange:!1})}return o}],t.hasOwnProperty("minimum")&&(r.props.min=t.minimum),t.hasOwnProperty("maximum")&&(r.props.max=t.maximum),t.hasOwnProperty("exclusiveMinimum")&&(r.props.exclusiveMinimum=t.exclusiveMinimum,this.addValidator(r,"exclusiveMinimum",({value:o})=>O(o)||o>t.exclusiveMinimum)),t.hasOwnProperty("exclusiveMaximum")&&(r.props.exclusiveMaximum=t.exclusiveMaximum,this.addValidator(r,"exclusiveMaximum",({value:o})=>O(o)||o<t.exclusiveMaximum)),t.hasOwnProperty("multipleOf")&&(r.props.step=t.multipleOf,this.addValidator(r,"multipleOf",({value:o})=>{if(O(o)||typeof o!="number"||o===0||t.multipleOf<=0)return!0;let p=Math.pow(10,Gi(t.multipleOf));return Math.round(o*p)%Math.round(t.multipleOf*p)===0}));break}case"string":{r.parsers=[(o,p)=>(d.indexOf("null")!==-1?o=O(o)?null:o:p&&!p.props.required&&(o=o===""?void 0:o),o)],["minLength","maxLength","pattern"].forEach(o=>{t.hasOwnProperty(o)&&(r.props[o]=t[o])});break}case"object":{r.fieldGroup||(r.fieldGroup=[]);let{propDeps:o,schemaDeps:p}=this.resolveDependencies(t);Object.keys(t.properties||{}).forEach(l=>{let v=Array.isArray(t.required)&&t.required.indexOf(l)!==-1,k=this._toFieldConfig(t.properties[l],w(f({},a),{key:l,isOptional:n||!v}));if(r.fieldGroup.push(k),(v||o[l])&&(k.expressions=w(f({},k.expressions||{}),{"props.required":y=>{let _=y.parent,x=y.fieldGroup&&y.key!=null?_.model:y.model;for(;_.key==null&&_.parent;)_=_.parent;let M=_&&_.props?_.props.required:!1;return!x&&!M?!1:Array.isArray(t.required)&&t.required.indexOf(l)!==-1?!0:o[l]&&y.model&&o[l].some(U=>!O(y.model[U]))}})),p[l]){let y=x=>x.hasOwnProperty("const")?x.const:x.enum[0],_=p[l].oneOf;_&&_.every(x=>x.properties&&x.properties[l]&&Kt(x.properties[l]))?_.forEach(x=>{let te=x.properties,{[l]:M}=te,U=Z(te,[ie(l)]);r.fieldGroup.push(w(f({},this._toFieldConfig(w(f({},x),{properties:U}),w(f({},a),{shareFormControl:!1,resetOnHide:!0}))),{expressions:{hide:ee=>!ee.model||y(M)!==ee.model[l]}}))}):r.fieldGroup.push(w(f({},this._toFieldConfig(p[l],a)),{expressions:{hide:x=>!x.model||O(x.model[l])}}))}}),t.oneOf&&r.fieldGroup.push(this.resolveMultiSchema("oneOf",t.oneOf,w(f({},a),{shareFormControl:!1}))),t.anyOf&&r.fieldGroup.push(this.resolveMultiSchema("anyOf",t.anyOf,a)),a.conditionalSchemas&&a.conditionalSchemas.forEach(v=>{let k=v._ifCondition;if(k&&v.properties){let y={fieldGroup:[],expressions:{hide:_=>{if(!_.model)return!0;let M=_.model[k.property]===k.value;return k.negate?M:!M}}};Object.keys(v.properties).forEach(_=>{let x=v.properties[_];if(!x)return;let M=Array.isArray(v.required)&&v.required.indexOf(_)!==-1,U=this._toFieldConfig(x,w(f({},a),{key:_,isOptional:!M,resetOnHide:!0}));y.fieldGroup.push(U)}),r.fieldGroup.push(y)}});break}case"array":{t.hasOwnProperty("minItems")&&(r.props.minItems=t.minItems,this.addValidator(r,"minItems",({value:o})=>O(o)||o.length>=t.minItems),!n&&t.minItems>0&&r.defaultValue===void 0&&(r.defaultValue=Array.from(new Array(t.minItems)))),t.hasOwnProperty("maxItems")&&(r.props.maxItems=t.maxItems,this.addValidator(r,"maxItems",({value:o})=>O(o)||o.length<=t.maxItems)),t.hasOwnProperty("uniqueItems")&&(r.props.uniqueItems=t.uniqueItems,this.addValidator(r,"uniqueItems",({value:o})=>O(o)||!t.uniqueItems?!0:Array.from(new Set(o.map(l=>JSON.stringify(l,(v,k)=>X(k)?Object.keys(k).sort().reduce((y,_)=>(y[_]=k[_],y),{}):k)))).length===o.length)),t.items&&!Array.isArray(t.items)&&(t.items=this.resolveSchema(t.items,a)),this.isEnum(t)||(r.fieldArray=o=>{let p=o.fieldGroup?o.fieldGroup.length:0,l=t.items;if(!Array.isArray(l)){if(!l)return{};let y=l.oneOf||l.anyOf,_=this._toFieldConfig(l,y?w(f({},a),{key:`${p}`,isOptional:!1}):w(f({},a),{isOptional:!1}));return y&&!W(_)&&(_.key=null),_}let v=l[p]?l[p]:t.additionalItems,k=v?this._toFieldConfig(v,a):{};return k.props&&(k.props.required=!0),l[p]&&(k.props.removable=!1),k});break}}if(t.hasOwnProperty("const")&&(r.props.const=t.const,this.addValidator(r,"const",({value:o})=>o===t.const),r.type||(r.defaultValue=t.const)),this.isEnum(t)){let o=this.toEnumOptions(t),p=r.type==="array";r.type="enum",r.props.multiple=p,r.props.options=o;let l=o.map(v=>v.value);this.addValidator(r,"enum",({value:v})=>v===void 0?!0:p?Array.isArray(v)?v.every(k=>l.includes(k)):!1:l.includes(v))}return t.oneOf&&!r.type&&(delete r.key,r.fieldGroup=[this.resolveMultiSchema("oneOf",t.oneOf,w(f({},a),{key:e,shareFormControl:!1}))]),t.anyOf&&!r.type&&(delete r.key,r.fieldGroup=[this.resolveMultiSchema("oneOf",t.anyOf,w(f({},a),{key:e,shareFormControl:!1}))]),t.widget?.formlyConfig&&(r=this.mergeFields(r,t.widget.formlyConfig)),r.templateOptions=r.props,a.map?a.map(r,t):r}resolveSchema(t,e){if(t&&t.$ref&&(t=this.resolveDefinition(t,e)),t&&t.allOf&&(t=this.resolveAllOf(t,e)),t&&(t.if||t.then||t.else)){let n=this.resolveIfThenElse(t,e);n.length>0&&(e.conditionalSchemas=n)}return t}resolveAllOf(a,n){var c=a,{allOf:t}=c,e=Z(c,["allOf"]);if(!t.length)throw Error(`allOf array can not be empty ${t}.`);return t.reduce((h,d)=>(d=this.resolveSchema(d,n),h.required&&d.required&&(h.required=[...h.required,...d.required]),d.uniqueItems&&(h.uniqueItems=d.uniqueItems),["maxLength","maximum","exclusiveMaximum","maxItems","maxProperties"].forEach(r=>{!O(h[r])&&!O(d[r])&&(h[r]=h[r]<d[r]?h[r]:d[r])}),["minLength","minimum","exclusiveMinimum","minItems","minProperties"].forEach(r=>{!O(h[r])&&!O(d[r])&&(h[r]=h[r]>d[r]?h[r]:d[r])}),We(h,d)),e)}resolveMultiSchema(t,e,n){return{type:"multischema",fieldGroup:[{type:"enum",defaultValue:-1,props:{multiple:t==="anyOf",options:e.map((a,c)=>({label:a.title,value:c,disabled:a.readOnly}))},hooks:{onInit:a=>a.formControl.valueChanges.pipe(de(()=>a.options.detectChanges(a.parent)))}},{fieldGroup:e.map((a,c)=>w(f({},this._toFieldConfig(a,w(f({},n),{resetOnHide:!0}))),{expressions:{hide:(h,d)=>{let r=h.parent.parent.fieldGroup[0].formControl;if(r.value===-1||d){let o=h.parent.fieldGroup.map((p,l)=>[p,l,this.isFieldValid(p,l,e,n)]).sort(([p,,l],[v,,k])=>{if(l!==k)return k?1:-1;let y=wt(p),_=wt(v);return y===_&&p.props.disabled===v.props.disabled?0:_>y?1:-1}).map(([,p])=>p);if(t==="anyOf"){let p=o.filter(l=>wt(h.parent.fieldGroup[l]));o=p.length>0?p:[o[0]||0]}o=o.length>0?o:[0],r.setValue(t==="anyOf"?o:o[0])}return Array.isArray(r.value)?r.value.indexOf(c)===-1:r.value!==c}}}))}]}}resolveDefinition(t,e){let[n,a]=t.$ref.split("#/");if(n)throw Error(`Remote schemas for ${t.$ref} not supported yet.`);let c=a?a.split("/").reduce((h,d)=>h?.hasOwnProperty(d)?h[d]:null,e.schema):null;if(!c)throw Error(`Cannot find a definition for ${t.$ref}.`);return c.$ref?this.resolveDefinition(c,e):f(f({},c),["title","description","default","widget"].reduce((h,d)=>(t.hasOwnProperty(d)&&(h[d]=t[d]),h),{}))}resolveDependencies(t){let e={},n={};return Object.keys(t.dependencies||{}).forEach(a=>{let c=t.dependencies[a];Array.isArray(c)?c.forEach(h=>{e[h]?e[h].push(a):e[h]=[a]}):n[a]=c}),{propDeps:e,schemaDeps:n}}extractIfCondition(t){if(t.properties){let e=Object.keys(t.properties)[0];if(e){let n=t.properties[e];if(n&&n.hasOwnProperty("const"))return{property:e,value:n.const}}}return null}resolveIfThenElse(t,e){let n=[];if(t.if&&typeof t.if=="object"){let a=this.extractIfCondition(t.if);if(a){if(t.then&&typeof t.then=="object"){let c=this.resolveConditionalSchema(t.then,e);n.push(w(f({},c),{_ifCondition:a}))}if(t.else&&typeof t.else=="object"){let c=this.resolveConditionalSchema(t.else,e);n.push(w(f({},c),{_ifCondition:{property:a.property,value:a.value,negate:!0}}))}}}return n}resolveConditionalSchema(t,e){let n=t;return t.$ref&&(n=this.resolveDefinition(t,e)),n.allOf&&(n=this.resolveAllOf(n,e)),n}guessSchemaType(t){let e=t?.type;return!e&&t?.properties?["object"]:Array.isArray(e)?e.length===1?e:e.length===2&&e.indexOf("null")!==-1?e.sort(n=>n=="null"?1:-1):e:e?[e]:[]}addValidator(t,e,n){t.validators=t.validators||{},t.validators[e]=n}isEnum(t){return!!t.enum||t.anyOf&&t.anyOf.every(Kt)||t.oneOf&&t.oneOf.every(Kt)||t.uniqueItems&&t.items&&!Array.isArray(t.items)&&this.isEnum(t.items)}toEnumOptions(t){if(t.enum)return t.enum.map(n=>({value:n,label:n}));let e=n=>{let a=n.hasOwnProperty("const")?n.const:n.enum[0],c={value:a,label:n.title||a};return n.readOnly&&(c.disabled=!0),c};return t.anyOf?t.anyOf.map(e):t.oneOf?t.oneOf.map(e):this.toEnumOptions(t.items)}isFieldValid(t,e,n,a){let c=n[e];c._field||Object.defineProperty(c,"_field",{enumerable:!1,writable:!0,configurable:!0});let h=c._field,d=t.model?t.model:t.fieldArray?[]:{};return t.model&&W(t)&&(d={[Array.isArray(t.key)?t.key.join("."):t.key]:xt(t)}),d=qt(d),h?(h.model=d,t.options.build(h)):h=c._field=t.options.build({form:Array.isArray(d)?new qe([]):new He({}),fieldGroup:[this._toFieldConfig(c,w(f({},a),{resetOnHide:!0,ignoreDefault:!0,map:null}))],model:d,options:{}}),h.form.valid}mergeFields(t,e){for(let n in e){let a=n==="templateOptions"?"props":n;X(t[a])&&X(e[n])?t[a]=this.mergeFields(t[a],e[n]):e[n]!=null&&(t[a]=e[n])}return t}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275prov=E({token:i,factory:i.\u0275fac,providedIn:"root"})}}return i})()});var ei,St,Qn,$i=S(()=>{"use strict";I();ut();$();I();ei="sp_task_widget_settings",St={isEnabled:!1,isAlwaysShow:!1,opacity:95},Qn=(()=>{class i{constructor(){this._settings=V(this._loadFromStorage()),this.settings=this._settings.asReadonly(),A&&this._notifyElectron(this._settings())}update(t){let e=f(f({},this._settings()),t);this._settings.set(e),this._persistToStorage(e),A&&this._notifyElectron(e)}_loadFromStorage(){if(typeof localStorage>"u")return f({},St);try{let t=localStorage.getItem(ei);if(!t)return f({},St);let e=JSON.parse(t);return f(f({},St),e)}catch(t){return b.err("Failed to read task widget settings from localStorage",t),f({},St)}}_persistToStorage(t){if(!(typeof localStorage>"u"))try{localStorage.setItem(ei,JSON.stringify(t))}catch(e){b.err("Failed to persist task widget settings to localStorage",e)}}_notifyElectron(t){typeof window>"u"||!window.ea||window.ea.updateTaskWidgetSettings(t)}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275prov=E({token:i,factory:i.\u0275fac,providedIn:"root"})}}return i})()});var Qi,ii,ni=S(()=>{"use strict";ut();Qi=["win-store","mac-store","linux-snap"],ii=()=>{if(!A)return!1;let i=window.ea?.getDistChannel?.();return!i||!Qi.includes(i)}});var ai,ri,oi=S(()=>{"use strict";ai=i=>{let s=i.trim().replace(/^v/i,"").match(/^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?/);return s?{major:Number(s[1]),minor:Number(s[2]),patch:Number(s[3]),prerelease:s[4]??null}:null},ri=(i,s)=>{let t=ai(i),e=ai(s);return!t||!e?!1:t.major!==e.major?t.major>e.major:t.minor!==e.minor?t.minor>e.minor:t.patch!==e.patch?t.patch>e.patch:t.prerelease===null&&e.prerelease!==null}});var Wi,Xi,Yi,Ji,Zi,_a,tn=S(()=>{"use strict";I();vi();Et();ot();fi();Ut();Fe();oi();Pi();Ri();Gt();jt();$();ni();I();Wi="https://api.github.com/repos/super-productivity/super-productivity/releases/latest",Xi=30*1e3,Yi=1440*60*1e3,Ji=15*1e3,Zi=/^v?\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/,_a=(()=>{class i{constructor(){this._http=m(Se),this._globalConfigService=m(ft),this._bannerService=m($e),this._snackService=m(N),this._isCheckInFlight=!1}init(){ii()&&this._globalConfigService.misc$.pipe(et(t=>t?.isCheckForUpdates!==!1),le(),at(t=>t?oe(Xi,Yi):j)).subscribe(()=>this.checkForUpdate())}checkForUpdate(){return u(this,arguments,function*({isUserTriggered:t=!1}={}){if(!this._isCheckInFlight){this._isCheckInFlight=!0;try{let n=(yield tt(this._http.get(Wi,{headers:{Accept:"application/vnd.github+json"}}).pipe(re(Ji)))).tag_name;if(!n||!Zi.test(n))throw new Error("Malformed release data");if(!ri(n,Bt.version)){t&&this._snackService.open({type:"SUCCESS",msg:g.APP.UPDATE_CHECK.UP_TO_DATE,translateParams:{version:Bt.version}});return}if(!t&&localStorage.getItem(C.UPDATE_CHECK_DISMISSED_VERSION)===n)return;this._showUpdateBanner(n)}catch(e){b.log("Update check failed",{error:e?.message}),t&&this._snackService.open({type:"ERROR",msg:g.APP.UPDATE_CHECK.ERROR})}finally{this._isCheckInFlight=!1}}})}_showUpdateBanner(t){let e=`https://github.com/super-productivity/super-productivity/releases/tag/${t}`;this._bannerService.open({id:Ke.UpdateAvailable,msg:g.APP.B_UPDATE_AVAILABLE.MSG,translateParams:{version:t},ico:"file_download",isHideDismissBtn:!0,action:{label:g.APP.B_UPDATE_AVAILABLE.DOWNLOAD,fn:()=>{this._rememberVersion(t),window.ea.openExternalUrl(e)}},action2:{label:g.G.DISMISS,fn:()=>this._rememberVersion(t)}})}_rememberVersion(t){localStorage.setItem(C.UPDATE_CHECK_DISMISSED_VERSION,t)}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275prov=E({token:i,factory:i.\u0275fac,providedIn:"root"})}}return i})()});var ci,si,J,$t,It,Y,li,Qt,mi=S(()=>{"use strict";Ht();Oi();ci=i=>{let s=i?.ids;return Array.isArray(s)?s.length:0},si=i=>ci(i?.task),J=i=>{if(!i||typeof i!="object")return 0;let s=i;return ci(s.task)+si(s.archiveYoung)+si(s.archiveOld)},$t=i=>{if(!i)return null;try{return J(JSON.parse(i))}catch(s){return null}},It=i=>{if(!i)return null;try{let s=JSON.parse(i),t=s.project?.ids;return{taskCount:J(s),projectCount:Array.isArray(t)?t.filter(e=>e!==Te.id).length:0}}catch(s){return null}},Y=i=>{if(!i)return!1;try{return D(JSON.parse(i))}catch(s){return!1}},li=i=>{if(!i)return!1;try{let t=JSON.parse(i).globalConfig?.sync;return t?t.isEnabled===!0||t.syncProvider!==null&&t.syncProvider!==void 0:!1}catch(s){return!1}},Qt=(i,s)=>Y(i)?i:Y(s)?s:i||s||null});var nn,an,Ot,Wt,Ct,Xt,rn,on,qa,sn=S(()=>{"use strict";I();Ce();Fe();Et();ot();ze();gi();ut();bi();Be();Ne();Bi();Ut();we();Ht();mi();Ci();Gt();$();Re();zi();Ei();jt();I();nn=300*1e3,an=30*1e3,Ot="backup",Wt="backup_prev",Ct="super-productivity-backup.json",Xt="super-productivity-backup.prev.json",rn=3,on=10,qa=(()=>{class i{constructor(){this._destroyRef=m(rt),this._configService=m(ft),this._stateSnapshotService=m(vt),this._backupService=m(kt),this._localDraftService=m(Qe),this._snackService=m(N),this._translateService=m(_t),this._platformService=m(Xe),this._localActions$=m(yt),this._isAndroidWebView=m(ye),this._cfg$=this._configService.cfg$.pipe(et(t=>t.localBackup)),this._triggerBackupSave$=this._cfg$.pipe(at(t=>t.isEnabled?it(se(nn),this._localActions$.pipe(nt(an))):j),me(()=>ae(this._backup()).pipe(ce(t=>(b.err("LocalBackupService: Backup failed",t),j)))))}init(){this._triggerBackupSave$.pipe(Q(this._destroyRef)).subscribe()}checkBackupAvailable(){return this._isAndroidWebView?u(this,null,function*(){return(yield this._loadAndroidDbValueSafe(Ot))?!0:!!(yield this._loadAndroidDbValueSafe(Wt))}):this._platformService.isIOS()?this._checkBackupAvailableIOS():A?window.ea.checkBackupAvailable():Promise.resolve(!1)}loadBackupElectron(t){return window.ea.loadBackupData(t)}loadBackupAndroid(){return u(this,null,function*(){let[t,e]=yield Promise.all([this._loadAndroidDbValueSafe(Ot),this._loadAndroidDbValueSafe(Wt)]);return Qt(t,e)??""})}_loadAndroidDbValueSafe(t){return u(this,null,function*(){try{let e=yield this._nativeDbLoad(t);return b.log(`LocalBackupService: read Android backup '${t}' (${e?e.length:0} chars)`),e}catch(e){return b.err(`LocalBackupService: failed to read Android backup '${t}'`,e),null}})}_nativeDbLoad(t){return zt.loadFromDbWrapped(t)}_nativeDbSave(t,e){return zt.saveToDbWrapped(t,e)}loadBackupIOS(){return u(this,null,function*(){let[t,e]=yield Promise.all([this._readIOSFileOrNull(Ct),this._readIOSFileOrNull(Xt)]);return Qt(t,e)??""})}_loadBestMobileBackupStr(){return this._isAndroidWebView?this.loadBackupAndroid():this.loadBackupIOS()}_checkBackupAvailableIOS(){return u(this,null,function*(){let[t,e]=yield Promise.all([this._iosFileExists(Ct),this._iosFileExists(Xt)]);return t||e})}askForFileStoreBackupIfAvailable(){return u(this,null,function*(){if(!A&&!this._isAndroidWebView&&!this._platformService.isIOS())return;if(A){let e=yield this.checkBackupAvailable();if(typeof e!="boolean"&&B(this._translateService.instant(g.CONFIRM.RESTORE_FILE_BACKUP,{dir:e.folder,from:new Date(e.created).toLocaleString()}))){let n=yield this.loadBackupElectron(e.path);b.log("backupData loaded from Electron backup"),yield this._importBackup(n)}return}let t=yield this._loadBestMobileBackupStr();if(t){if(Y(t)&&!li(t)){if(b.log("mobile backupData auto-restored, length: "+t.length),yield this._importBackup(t)){let n=It(t);this._snackService.open({type:"SUCCESS",msg:g.GCF.AUTO_BACKUPS.S_AUTO_RESTORED,translateParams:{tasks:n?.taskCount??0,projects:n?.projectCount??0}})}return}B(this._restoreMobilePromptMsg(t))&&(b.log("mobile backupData loaded, length: "+t.length),yield this._importBackup(t))}})}restoreLatestMobileBackupFromSettings(){return u(this,null,function*(){if(!this._isAndroidWebView&&!this._platformService.isIOS())return;let t=yield this._loadBestMobileBackupStr();if(!Y(t)){this._snackService.open({type:"WARNING",msg:g.GCF.AUTO_BACKUPS.S_NO_BACKUP_AVAILABLE});return}B(this._restoreMobileFromSettingsPromptMsg(t))&&(b.log("mobile backupData loaded from settings, length: "+t.length),(yield this._importBackup(t))&&this._snackService.open({type:"SUCCESS",msg:g.GCF.AUTO_BACKUPS.S_RESTORE_SUCCESS}))})}_restoreMobilePromptMsg(t){let e=It(t);return e?this._translateService.instant(g.CONFIRM.RESTORE_FILE_BACKUP_MOBILE,{tasks:e.taskCount,projects:e.projectCount}):this._translateService.instant(g.CONFIRM.RESTORE_FILE_BACKUP_ANDROID)}_restoreMobileFromSettingsPromptMsg(t){let e=It(t);return this._translateService.instant(g.CONFIRM.RESTORE_FILE_BACKUP_MOBILE_FROM_SETTINGS,{tasks:e?.taskCount??0,projects:e?.projectCount??0})}_backup(){return u(this,null,function*(){let t=yield this._stateSnapshotService.getAllSyncModelDataFromStoreAsync();if(!D(t)){b.warn("LocalBackupService: skipping backup \u2014 empty state");return}let e=!1;A&&(yield this._backupElectron(t),e=!0),this._isAndroidWebView&&(yield this._backupAndroid(t))&&(e=!0),this._platformService.isIOS()&&(yield this._backupIOS(t))&&(e=!0),e&&this._recordLastBackupTime()})}_recordLastBackupTime(){try{localStorage.setItem(C.LAST_LOCAL_BACKUP,Date.now().toString())}catch(t){b.warn("LocalBackupService: failed to record last backup time",t)}}getLastBackupTime(){let t=localStorage.getItem(C.LAST_LOCAL_BACKUP);if(!t)return null;let e=Number(t);return Number.isFinite(e)?e:null}_backupElectron(t){return u(this,null,function*(){let e=yield tt(this._cfg$);yield window.ea.backupAppData({data:t,maxBackupFiles:e.maxBackupFiles??51})})}_isNearEmptyOverwrite(t,e){if(J(t)>=rn)return!1;let n=$t(e);return n===null?!1:n>=on}_guardNearEmptyOverwrite(t,e,n){return this._isNearEmptyOverwrite(t,e)?(b.warn(`LocalBackupService: skipping ${n} backup \u2014 near-empty (${J(t)} tasks) over substantial backup (${$t(e)} tasks). #7925 A3.`),!0):!1}_backupAndroid(t){return u(this,null,function*(){let e;try{e=yield this._nativeDbLoad(Ot)}catch(a){return b.err("LocalBackupService: skipping Android backup \u2014 could not read existing slot",a),!1}if(this._guardNearEmptyOverwrite(t,e,"Android"))return!1;e&&(yield this._nativeDbSave(Wt,e));let n=JSON.stringify(t);return b.log(`LocalBackupService: writing Android backup (${n.length} chars)`),yield this._nativeDbSave(Ot,n),!0})}_backupIOS(t){return u(this,null,function*(){let e;try{e=yield this._readIOSExistingSlotOrThrow(Ct)}catch(n){return b.err("LocalBackupService: skipping iOS backup \u2014 could not read existing slot",n),!1}if(this._guardNearEmptyOverwrite(t,e,"iOS"))return!1;try{return e&&(yield this._writeIOSFile(Xt,e)),yield this._writeIOSFile(Ct,JSON.stringify(t)),b.log("iOS backup saved successfully"),!0}catch(n){return b.err("Failed to save iOS backup",n),!1}})}_writeIOSFile(t,e){return u(this,null,function*(){yield bt.writeFile({path:t,data:e,directory:gt.Data,encoding:Vt.UTF8})})}_readIOSFileRaw(t){return u(this,null,function*(){return(yield bt.readFile({path:t,directory:gt.Data,encoding:Vt.UTF8})).data})}_readIOSFileOrNull(t){return u(this,null,function*(){try{return yield this._readIOSFileRaw(t)}catch(e){return null}})}_readIOSExistingSlotOrThrow(t){return u(this,null,function*(){try{return yield this._readIOSFileRaw(t)}catch(e){if(!(yield this._iosFileExists(t)))return null;throw e}})}_iosFileExists(t){return u(this,null,function*(){try{return!!(yield bt.stat({path:t,directory:gt.Data}))}catch(e){return!1}})}_importBackup(t){return u(this,null,function*(){try{return yield this._backupService.importCompleteBackup(JSON.parse(t),!1,!0,!0),this._localDraftService.deleteAllDrafts(),!0}catch(e){return this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.S_ERR_IMPORT_FAILED}),!1}})}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275prov=E({token:i,factory:i.\u0275fac,providedIn:"root"})}}return i})()});var cn,ln,mn,dn,hn,pn,un,_n,fn,gn,di,bn,vn,kn,Yt,yn,Cr,Er,xn=S(()=>{"use strict";I();I();Si();Li();xi();Et();Di();Ii();Mi();wi();cn=["*"],ln=`.mdc-list {
  margin: 0;
  padding: 8px 0;
  list-style-type: none;
}
.mdc-list:focus {
  outline: none;
}

.mdc-list-item {
  display: flex;
  position: relative;
  justify-content: flex-start;
  overflow: hidden;
  padding: 0;
  align-items: stretch;
  cursor: pointer;
  padding-left: 16px;
  padding-right: 16px;
  background-color: var(--mat-list-list-item-container-color, transparent);
  border-radius: var(--mat-list-list-item-container-shape, var(--mat-sys-corner-none));
}
.mdc-list-item.mdc-list-item--selected {
  background-color: var(--mat-list-list-item-selected-container-color);
}
.mdc-list-item:focus {
  outline: 0;
}
.mdc-list-item.mdc-list-item--disabled {
  cursor: auto;
}
.mdc-list-item.mdc-list-item--with-one-line {
  height: var(--mat-list-list-item-one-line-container-height, 48px);
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__start {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-two-lines {
  height: var(--mat-list-list-item-two-line-container-height, 64px);
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-three-lines {
  height: var(--mat-list-list-item-three-line-container-height, 88px);
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--selected::before, .mdc-list-item.mdc-list-item--selected:focus::before, .mdc-list-item:not(.mdc-list-item--selected):focus::before {
  position: absolute;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  content: "";
  pointer-events: none;
}

a.mdc-list-item {
  color: inherit;
  text-decoration: none;
}

.mdc-list-item__start {
  fill: currentColor;
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-leading-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-leading-icon-size, 24px);
  height: var(--mat-list-list-item-leading-icon-size, 24px);
  margin-left: 16px;
  margin-right: 32px;
}
[dir=rtl] .mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-left: 32px;
  margin-right: 16px;
}
.mdc-list-item--with-leading-icon:hover .mdc-list-item__start {
  color: var(--mat-list-list-item-hover-leading-icon-color);
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start {
  width: var(--mat-list-list-item-leading-avatar-size, 40px);
  height: var(--mat-list-list-item-leading-avatar-size, 40px);
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start, [dir=rtl] .mdc-list-item--with-leading-avatar .mdc-list-item__start {
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}

.mdc-list-item__end {
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  font-family: var(--mat-list-list-item-trailing-supporting-text-font, var(--mat-sys-label-small-font));
  line-height: var(--mat-list-list-item-trailing-supporting-text-line-height, var(--mat-sys-label-small-line-height));
  font-size: var(--mat-list-list-item-trailing-supporting-text-size, var(--mat-sys-label-small-size));
  font-weight: var(--mat-list-list-item-trailing-supporting-text-weight, var(--mat-sys-label-small-weight));
  letter-spacing: var(--mat-list-list-item-trailing-supporting-text-tracking, var(--mat-sys-label-small-tracking));
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-trailing-icon-size, 24px);
  height: var(--mat-list-list-item-trailing-icon-size, 24px);
}
.mdc-list-item--with-trailing-icon:hover .mdc-list-item__end {
  color: var(--mat-list-list-item-hover-trailing-icon-color);
}
.mdc-list-item.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-supporting-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-list-item--selected.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-selected-trailing-icon-color, var(--mat-sys-primary));
}

.mdc-list-item__content {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  align-self: center;
  flex: 1;
  pointer-events: none;
}
.mdc-list-item--with-two-lines .mdc-list-item__content, .mdc-list-item--with-three-lines .mdc-list-item__content {
  align-self: stretch;
}

.mdc-list-item__primary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: var(--mat-list-list-item-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-list-list-item-label-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-list-list-item-label-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-list-list-item-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-list-list-item-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-list-list-item-label-text-tracking, var(--mat-sys-body-large-tracking));
}
.mdc-list-item:hover .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-hover-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item:focus .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-focus-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text, .mdc-list-item--with-three-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}

.mdc-list-item__secondary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  display: block;
  margin-top: 0;
  color: var(--mat-list-list-item-supporting-text-color, var(--mat-sys-on-surface-variant));
  font-family: var(--mat-list-list-item-supporting-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-list-list-item-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-list-list-item-supporting-text-size, var(--mat-sys-body-medium-size));
  font-weight: var(--mat-list-list-item-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-list-list-item-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}
.mdc-list-item__secondary-text::before {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-three-lines .mdc-list-item__secondary-text {
  white-space: normal;
  line-height: 20px;
}
.mdc-list-item--with-overline .mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: auto;
}

.mdc-list-item--with-leading-radio.mdc-list-item,
.mdc-list-item--with-leading-checkbox.mdc-list-item,
.mdc-list-item--with-leading-icon.mdc-list-item,
.mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
[dir=rtl] .mdc-list-item--with-leading-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-checkbox.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-icon.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  display: block;
  margin-top: 0;
  line-height: normal;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-trailing-icon.mdc-list-item, [dir=rtl] .mdc-list-item--with-trailing-icon.mdc-list-item {
  padding-left: 0;
  padding-right: 0;
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 16px;
}

.mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  -webkit-user-select: none;
  user-select: none;
  margin-left: 28px;
  margin-right: 16px;
}
[dir=rtl] .mdc-list-item--with-trailing-meta .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 28px;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end {
  display: block;
  line-height: normal;
  align-self: flex-start;
  margin-top: 0;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end::before, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-leading-radio .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 8px;
  margin-right: 24px;
}
[dir=rtl] .mdc-list-item--with-leading-radio .mdc-list-item__start,
[dir=rtl] .mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 24px;
  margin-right: 8px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-item--with-trailing-radio.mdc-list-item,
.mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-left: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, [dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-right: 0;
}
.mdc-list-item--with-trailing-radio .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 24px;
  margin-right: 8px;
}
[dir=rtl] .mdc-list-item--with-trailing-radio .mdc-list-item__end,
[dir=rtl] .mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 8px;
  margin-right: 24px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-three-lines .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-group__subheader {
  margin: 0.75rem 16px;
}

.mdc-list-item--disabled .mdc-list-item__start,
.mdc-list-item--disabled .mdc-list-item__content,
.mdc-list-item--disabled .mdc-list-item__end {
  opacity: 1;
}
.mdc-list-item--disabled .mdc-list-item__primary-text,
.mdc-list-item--disabled .mdc-list-item__secondary-text {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}
.mdc-list-item--disabled.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-disabled-leading-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-leading-icon-opacity, 0.38);
}
.mdc-list-item--disabled.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-disabled-trailing-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-trailing-icon-opacity, 0.38);
}

.mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing, [dir=rtl] .mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing {
  padding-left: 0;
  padding-right: 0;
}

.mdc-list-item.mdc-list-item--disabled .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-disabled-label-text-color, var(--mat-sys-on-surface));
}

.mdc-list-item:hover::before {
  background-color: var(--mat-list-list-item-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}

.mdc-list-item.mdc-list-item--disabled::before {
  background-color: var(--mat-list-list-item-disabled-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item:focus::before {
  background-color: var(--mat-list-list-item-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item--disabled .mdc-radio,
.mdc-list-item--disabled .mdc-checkbox {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}

.mdc-list-item--with-leading-avatar .mat-mdc-list-item-avatar {
  border-radius: var(--mat-list-list-item-leading-avatar-shape, var(--mat-sys-corner-full));
  background-color: var(--mat-list-list-item-leading-avatar-color, var(--mat-sys-primary-container));
}

.mat-mdc-list-item-icon {
  font-size: var(--mat-list-list-item-leading-icon-size, 24px);
}

@media (forced-colors: active) {
  a.mdc-list-item--activated::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  a.mdc-list-item--activated [dir=rtl]::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-list-base {
  display: block;
}
.mat-mdc-list-base .mdc-list-item__start,
.mat-mdc-list-base .mdc-list-item__end,
.mat-mdc-list-base .mdc-list-item__content {
  pointer-events: auto;
}

.mat-mdc-list-item,
.mat-mdc-list-option {
  width: 100%;
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-list-item:not(.mat-mdc-list-item-interactive),
.mat-mdc-list-option:not(.mat-mdc-list-item-interactive) {
  cursor: default;
}
.mat-mdc-list-item .mat-divider-inset,
.mat-mdc-list-option .mat-divider-inset {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
}
.mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
.mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-left: 72px;
}
[dir=rtl] .mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
[dir=rtl] .mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-right: 72px;
}

.mat-mdc-list-item-interactive::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  content: "";
  opacity: 0;
  pointer-events: none;
  border-radius: inherit;
}

.mat-mdc-list-item > .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-list-item:focus-visible > .mat-focus-indicator::before {
  content: "";
}

.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-line.mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: normal;
}
.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-unscoped-content.mdc-list-item__secondary-text {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

mat-action-list button {
  background: none;
  color: inherit;
  border: none;
  font: inherit;
  outline: inherit;
  -webkit-tap-highlight-color: transparent;
  text-align: start;
}
mat-action-list button::-moz-focus-inner {
  border: 0;
}

.mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-inline-start: var(--mat-list-list-item-leading-icon-start-space, 16px);
  margin-inline-end: var(--mat-list-list-item-leading-icon-end-space, 16px);
}

.mat-mdc-nav-list .mat-mdc-list-item {
  border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
  --mat-focus-indicator-border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
}
.mat-mdc-nav-list .mat-mdc-list-item.mdc-list-item--activated {
  background-color: var(--mat-list-active-indicator-color, var(--mat-sys-secondary-container));
}
`,mn=["unscopedContent"],dn=["text"],hn=[[["","matListItemAvatar",""],["","matListItemIcon",""]],[["","matListItemTitle",""]],[["","matListItemLine",""]],"*",[["","matListItemMeta",""]],[["mat-divider"]]],pn=["[matListItemAvatar],[matListItemIcon]","[matListItemTitle]","[matListItemLine]","*","[matListItemMeta]","mat-divider"],un=new At("ListOption"),_n=(()=>{class i{_elementRef=m(st);constructor(){}static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,selectors:[["","matListItemTitle",""]],hostAttrs:[1,"mat-mdc-list-item-title","mdc-list-item__primary-text"]})}return i})(),fn=(()=>{class i{_elementRef=m(st);constructor(){}static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,selectors:[["","matListItemLine",""]],hostAttrs:[1,"mat-mdc-list-item-line","mdc-list-item__secondary-text"]})}return i})(),gn=(()=>{class i{static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,selectors:[["","matListItemMeta",""]],hostAttrs:[1,"mat-mdc-list-item-meta","mdc-list-item__end"]})}return i})(),di=(()=>{class i{_listOption=m(un,{optional:!0});constructor(){}_isAlignedAtStart(){return!this._listOption||this._listOption?._getTogglePosition()==="after"}static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,hostVars:4,hostBindings:function(e,n){e&2&&ht("mdc-list-item__start",n._isAlignedAtStart())("mdc-list-item__end",!n._isAlignedAtStart())}})}return i})(),bn=(()=>{class i extends di{static \u0275fac=(()=>{let t;return function(n){return(t||(t=G(i)))(n||i)}})();static \u0275dir=L({type:i,selectors:[["","matListItemAvatar",""]],hostAttrs:[1,"mat-mdc-list-item-avatar"],features:[q]})}return i})(),vn=(()=>{class i extends di{static \u0275fac=(()=>{let t;return function(n){return(t||(t=G(i)))(n||i)}})();static \u0275dir=L({type:i,selectors:[["","matListItemIcon",""]],hostAttrs:[1,"mat-mdc-list-item-icon"],features:[q]})}return i})(),kn=new At("MAT_LIST_CONFIG"),Yt=(()=>{class i{_isNonInteractive=!0;get disableRipple(){return this._disableRipple}set disableRipple(t){this._disableRipple=P(t)}_disableRipple=!1;get disabled(){return this._disabled()}set disabled(t){this._disabled.set(P(t))}_disabled=V(!1);_defaultOptions=m(kn,{optional:!0});static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,hostVars:1,hostBindings:function(e,n){e&2&&ct("aria-disabled",n.disabled)},inputs:{disableRipple:"disableRipple",disabled:"disabled"}})}return i})(),yn=(()=>{class i{_elementRef=m(st);_ngZone=m(pe);_listBase=m(Yt,{optional:!0});_platform=m(Ee);_hostElement;_isButtonElement;_noopAnimations=Me();_avatars;_icons;set lines(t){this._explicitLines=Le(t,null),this._updateItemLines(!1)}_explicitLines=null;get disableRipple(){return this.disabled||this._disableRipple||this._noopAnimations||!!this._listBase?.disableRipple}set disableRipple(t){this._disableRipple=P(t)}_disableRipple=!1;get disabled(){return this._disabled()||!!this._listBase?.disabled}set disabled(t){this._disabled.set(P(t))}_disabled=V(!1);_subscriptions=new ne;_rippleRenderer=null;_hasUnscopedTextContent=!1;rippleConfig;get rippleDisabled(){return this.disableRipple||!!this.rippleConfig.disabled}constructor(){m(Ae).load(Ve);let t=m(je,{optional:!0});this.rippleConfig=t||{},this._hostElement=this._elementRef.nativeElement,this._isButtonElement=this._hostElement.nodeName.toLowerCase()==="button",this._listBase&&!this._listBase._isNonInteractive&&this._initInteractiveListItem(),this._isButtonElement&&!this._hostElement.hasAttribute("type")&&this._hostElement.setAttribute("type","button")}ngAfterViewInit(){this._monitorProjectedLinesAndTitle(),this._updateItemLines(!0)}ngOnDestroy(){this._subscriptions.unsubscribe(),this._rippleRenderer!==null&&this._rippleRenderer._removeTriggerEvents()}_hasIconOrAvatar(){return!!(this._avatars.length||this._icons.length)}_initInteractiveListItem(){this._hostElement.classList.add("mat-mdc-list-item-interactive"),this._rippleRenderer=new Ue(this,this._ngZone,this._hostElement,this._platform,m(he)),this._rippleRenderer.setupTriggerEvents(this._hostElement)}_monitorProjectedLinesAndTitle(){this._ngZone.runOutsideAngular(()=>{this._subscriptions.add(it(this._lines.changes,this._titles.changes).subscribe(()=>this._updateItemLines(!1)))})}_updateItemLines(t){if(!this._lines||!this._titles||!this._unscopedContent)return;t&&this._checkDomForUnscopedTextContent();let e=this._explicitLines??this._inferLinesFromContent(),n=this._unscopedContent.nativeElement;if(this._hostElement.classList.toggle("mat-mdc-list-item-single-line",e<=1),this._hostElement.classList.toggle("mdc-list-item--with-one-line",e<=1),this._hostElement.classList.toggle("mdc-list-item--with-two-lines",e===2),this._hostElement.classList.toggle("mdc-list-item--with-three-lines",e===3),this._hasUnscopedTextContent){let a=this._titles.length===0&&e===1;n.classList.toggle("mdc-list-item__primary-text",a),n.classList.toggle("mdc-list-item__secondary-text",!a)}else n.classList.remove("mdc-list-item__primary-text"),n.classList.remove("mdc-list-item__secondary-text")}_inferLinesFromContent(){let t=this._titles.length+this._lines.length;return this._hasUnscopedTextContent&&(t+=1),t}_checkDomForUnscopedTextContent(){this._hasUnscopedTextContent=Array.from(this._unscopedContent.nativeElement.childNodes).filter(t=>t.nodeType!==t.COMMENT_NODE).some(t=>!!(t.textContent&&t.textContent.trim()))}static \u0275fac=function(e){return new(e||i)};static \u0275dir=L({type:i,contentQueries:function(e,n,a){if(e&1&&Rt(a,bn,4)(a,vn,4),e&2){let c;F(c=R())&&(n._avatars=c),F(c=R())&&(n._icons=c)}},hostVars:4,hostBindings:function(e,n){e&2&&(ct("aria-disabled",n.disabled)("disabled",n._isButtonElement&&n.disabled||null),ht("mdc-list-item--disabled",n.disabled))},inputs:{lines:"lines",disableRipple:"disableRipple",disabled:"disabled"}})}return i})(),Cr=(()=>{class i extends Yt{static \u0275fac=(()=>{let t;return function(n){return(t||(t=G(i)))(n||i)}})();static \u0275cmp=H({type:i,selectors:[["mat-list"]],hostAttrs:[1,"mat-mdc-list","mat-mdc-list-base","mdc-list"],exportAs:["matList"],features:[ve([{provide:Yt,useExisting:i}]),q],ngContentSelectors:cn,decls:1,vars:0,template:function(e,n){e&1&&(Ft(),T(0))},styles:[ln],encapsulation:2,changeDetection:0})}return i})(),Er=(()=>{class i extends yn{_lines;_titles;_meta;_unscopedContent;_itemText;get activated(){return this._activated}set activated(t){this._activated=P(t)}_activated=!1;_getAriaCurrent(){return this._hostElement.nodeName==="A"&&this._activated?"page":null}_hasBothLeadingAndTrailing(){return this._meta.length!==0&&(this._avatars.length!==0||this._icons.length!==0)}static \u0275fac=(()=>{let t;return function(n){return(t||(t=G(i)))(n||i)}})();static \u0275cmp=H({type:i,selectors:[["mat-list-item"],["a","mat-list-item",""],["button","mat-list-item",""]],contentQueries:function(e,n,a){if(e&1&&Rt(a,fn,5)(a,_n,5)(a,gn,5),e&2){let c;F(c=R())&&(n._lines=c),F(c=R())&&(n._titles=c),F(c=R())&&(n._meta=c)}},viewQuery:function(e,n){if(e&1&&fe(mn,5)(dn,5),e&2){let a;F(a=R())&&(n._unscopedContent=a.first),F(a=R())&&(n._itemText=a.first)}},hostAttrs:[1,"mat-mdc-list-item","mdc-list-item"],hostVars:13,hostBindings:function(e,n){e&2&&(ct("aria-current",n._getAriaCurrent()),ht("mdc-list-item--activated",n.activated)("mdc-list-item--with-leading-avatar",n._avatars.length!==0)("mdc-list-item--with-leading-icon",n._icons.length!==0)("mdc-list-item--with-trailing-meta",n._meta.length!==0)("mat-mdc-list-item-both-leading-and-trailing",n._hasBothLeadingAndTrailing())("_mat-animation-noopable",n._noopAnimations))},inputs:{activated:"activated"},exportAs:["matListItem"],features:[q],ngContentSelectors:pn,decls:10,vars:0,consts:[["unscopedContent",""],[1,"mdc-list-item__content"],[1,"mat-mdc-list-item-unscoped-content",3,"cdkObserveContent"],[1,"mat-focus-indicator"]],template:function(e,n){e&1&&(Ft(hn),T(0),K(1,"span",1),T(2,1),T(3,2),K(4,"span",2,0),_e("cdkObserveContent",function(){return n._updateItemLines(!0)}),T(6,3),lt()(),T(7,4),T(8,5),mt(9,"div",3))},dependencies:[De],encapsulation:2,changeDetection:0})}return i})()});var hi,wn,Sn,Jt,Dr,In=S(()=>{"use strict";Ai();hi=0,wn=["username","userName","loginName","password","token","apiKey","secret","authorization","notes","authCode","accessToken","host","gitlabBaseUrl","nextcloudBaseUrl","icalUrl","organization","syncFilePath","syncFolderPath","title","originalImgPath","path","content","repo","repoFullname","filterUserName","filterUsername","caldavUrl","api_key","resourceName","name","description","location","calProviderId","summary","filterIncludeRegex","filterExcludeRegex"],Sn=(i,s,t)=>wn.includes(i)&&s.length>0?`${i}__${t}`:s,Jt=i=>{if(!(typeof i!="object"||i===null))for(let s in i){if(Object.prototype.hasOwnProperty.call(i,s)){let t=i[s];Array.isArray(t)?t.forEach(e=>{typeof e=="object"&&e!==null&&Jt(e)}):typeof t=="object"&&t!==null?Jt(t):typeof t=="string"&&(i[s]=Sn(s,t,hi))}hi++}},Dr=i=>{let s=Pe(i);return Jt(s),JSON.stringify(s)}});var On,Cn,En,Rr,An=S(()=>{"use strict";$();Ui();On="./assets/snd",Cn=50,En=300,Rr=(i,s=0)=>u(null,null,function*(){let t=`${On}/${i.doneSound}`;Nt.log(t);let e=i.isIncreaseDoneSoundPitch?Math.min(s*Cn,En):0;try{let n=yield Ye(t);yield Je(n,i.volume,a=>{a.detune.value=e})}catch(n){Nt.err("Error playing done sound:",n)}})});var pi,ui=S(()=>{"use strict";pi=i=>i.remoteTimestamp!==null&&i.remoteHasData&&i.remoteTimestamp>i.syncedAt?"pull":i.localHasData&&(i.remoteTimestamp===null||!i.remoteHasData||i.dirty||i.syncedAt>i.remoteTimestamp)?"push":"idle"});var Ln,Dn,Mn,Zt,_i,Tn,io,Fn=S(()=>{"use strict";I();Ce();yi();Ne();Be();Ht();Gt();we();ze();jt();Ut();$();ot();Re();ut();ui();I();Ln=2e4,Dn=3e4,Mn="/api/backup?status=1",Zt="/api/backup",_i="sp-cloud-backup-nudge",Tn=i=>{let s={};return i!==void 0&&(s["Content-Type"]="application/json",s["x-sp-base-timestamp"]=String(i)),s},io=(()=>{class i{constructor(){this._backupService=m(kt),this._stateSnapshotService=m(vt),this._snackService=m(N),this._translateService=m(_t),this._router=m(Oe),this._localActions$=m(yt),this._destroyRef=m(rt),this._started=!1,this._watching=!1,this._configured=!1,this._busy=!1}get isAvailable(){return xe}isConfigured(){return u(this,null,function*(){try{let t=yield fetch(Mn,{cache:"no-store"});if(!t.ok)return!1;let e=yield t.json();return this._configured=!!e.configured,this._configured}catch(t){return!1}})}init(){return u(this,null,function*(){this._started||!this.isAvailable||(this._started=!0,yield this._bootstrap())})}uploadIfLocalHasData(t){return u(this,null,function*(){return this._reconcile({forcePush:t,announcePush:t,announceError:t})})}restoreFromCloud(t){return u(this,null,function*(){try{let e=yield fetch(Zt,{cache:"no-store"});if(e.status===404)return this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_EMPTY}),!1;if(!e.ok)throw new Error(yield e.text());let n=yield e.json(),a=this._stateSnapshotService.getAllSyncModelDataFromStore();if(!t&&D(a)&&!B(this._translateService.instant(g.FILE_IMEX.CLOUD_CONFIRM_RESTORE)))return!1;this._busy=!0;try{yield this._backupService.importCompleteBackup(n,!0,!0,!0),this._rememberSync(n)}finally{this._busy=!1}return this._snackService.open({type:"SUCCESS",msg:g.FILE_IMEX.CLOUD_RESTORED}),!0}catch(e){return this._busy=!1,b.err("WebCloudBackup restore failed",e),this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_RESTORE_FAILED}),!1}})}_bootstrap(){return u(this,null,function*(){if(!(yield this.isConfigured())){this._nudgeOnce({ico:"cloud_off",msg:g.FILE_IMEX.CLOUD_NOT_CONFIGURED});return}this._startWatching(),yield this._reconcile({forcePush:!1,announcePush:!1,announceError:!0})})}_nudgeOnce({ico:t,msg:e}){try{if(sessionStorage.getItem(_i))return;sessionStorage.setItem(_i,"1")}catch(n){}this._snackService.open({type:"CUSTOM",ico:t,msg:e,actionStr:g.FILE_IMEX.CLOUD_OPEN_SETTINGS,actionFn:()=>{this._router.navigate(["/config"])},config:{duration:1e4}})}_startWatching(){this._watching||(this._watching=!0,this._localActions$.pipe(Q(this._destroyRef)).subscribe(()=>{this._busy||localStorage.setItem(C.CLOUD_DIRTY,"1")}),this._localActions$.pipe(nt(Ln),Q(this._destroyRef)).subscribe(()=>{this._isDirty()&&this._reconcile({forcePush:!1,announcePush:!1,announceError:!1})}),this._pollTimer=window.setInterval(()=>{this._reconcile({forcePush:!1,announcePush:!1,announceError:!1})},Dn),this._destroyRef.onDestroy(()=>{this._pollTimer!==void 0&&window.clearInterval(this._pollTimer)}))}_reconcile(t){return u(this,null,function*(){if(this._busy)return!1;this._busy=!0;try{let e=yield this._fetchRemote();if(e.kind==="not-configured")return t.announceError&&this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_NOT_CONFIGURED}),!1;if(e.kind==="error")return t.announceError&&this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_SAVE_FAILED}),!1;let n=D(this._stateSnapshotService.getAllSyncModelDataFromStore()),a=pi({remoteTimestamp:e.kind==="backup"?e.timestamp:null,remoteHasData:e.kind==="backup"&&e.hasData,localHasData:n,syncedAt:this._syncedAt(),dirty:this._isDirty()});return a==="pull"&&e.kind==="backup"?(yield this._importRemote(e.backup),!1):a==="push"||t.forcePush&&n?yield this._putLocal(t.announcePush):t.forcePush&&!n?(this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_NOTHING_TO_SAVE}),!1):!t.forcePush}catch(e){return b.err("WebCloudBackup sync failed",e),t.announceError&&this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_SAVE_FAILED}),!1}finally{this._busy=!1}})}_putLocal(t){return u(this,null,function*(){let e=this._stateSnapshotService.getAllSyncModelDataFromStore();if(!D(e))return t&&this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_NOTHING_TO_SAVE}),!1;let n=yield this._backupService.loadCompleteBackup(!0),a=yield fetch(Zt,{method:"PUT",headers:Tn(this._syncedAt()),body:JSON.stringify(n)});if(a.status===409){let c=yield this._fetchRemote();return c.kind==="backup"&&c.hasData&&(yield this._importRemote(c.backup)),!1}if(a.status===503)return this._snackService.open({type:"ERROR",msg:g.FILE_IMEX.CLOUD_NOT_CONFIGURED}),!1;if(!a.ok)throw new Error(yield a.text());return this._rememberSync(n),t&&this._snackService.open({type:"SUCCESS",msg:g.FILE_IMEX.CLOUD_SAVED}),!0})}_importRemote(t){return u(this,null,function*(){yield this._backupService.importCompleteBackup(t,!0,!0,!0),this._rememberSync(t),this._snackService.open({type:"SUCCESS",msg:g.FILE_IMEX.CLOUD_RESTORED})})}_fetchRemote(){return u(this,null,function*(){let t=yield fetch(Zt,{cache:"no-store"});if(t.status===404)return{kind:"missing"};if(t.status===503)return{kind:"not-configured"};if(!t.ok)return{kind:"error"};let e=yield t.json();if(typeof e.timestamp!="number")return{kind:"error"};let n="data"in e?e.data:e;return{kind:"backup",backup:e,timestamp:e.timestamp,hasData:D(n)}})}_syncedAt(){let t=localStorage.getItem(C.CLOUD_SYNCED_AT),e=t?Number(t):0;return Number.isFinite(e)?e:0}_isDirty(){return localStorage.getItem(C.CLOUD_DIRTY)==="1"}_rememberSync(t){let e=typeof t.timestamp=="number"?t.timestamp:Date.now();localStorage.setItem(C.CLOUD_SYNCED_AT,String(e)),localStorage.removeItem(C.CLOUD_DIRTY)}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275prov=E({token:i,factory:i.\u0275fac,providedIn:"root"})}}return i})()});function Rn(i,s){if(i&1&&mt(0,"div",2),i&2){let t=dt();Pt("width",t.size()+"px")("height",t.size()+"px"),Tt("innerHTML",s,ue)}}function Pn(i,s){if(i&1&&(K(0,"mat-icon"),ge(1),lt()),i&2){let t=dt();Pt("font-size",t.size()+"px"),Lt(),be(t.fallbackIcon())}}var po,Bn=S(()=>{"use strict";I();ki();Vi();Ti();ji();I();po=(()=>{class i{constructor(){this._sanitizer=m(Ie),this._pluginService=m(ti),this.pluginId=pt.required(),this.size=pt(24),this.fallbackIcon=pt("extension"),this.sanitizedSvg=ke(()=>{let t=this.pluginId(),n=this._pluginService.getPluginIconsSignal()().get(t);if(!n)return null;let a=Ze(n);return a?this._sanitizer.bypassSecurityTrustHtml(a):null})}static{this.\u0275fac=function(e){return new(e||i)}}static{this.\u0275cmp=H({type:i,selectors:[["plugin-icon"]],inputs:{pluginId:[1,"pluginId"],size:[1,"size"],fallbackIcon:[1,"fallbackIcon"]},decls:2,vars:1,consts:[[1,"plugin-svg-icon",3,"innerHTML","width","height"],[3,"font-size"],[1,"plugin-svg-icon",3,"innerHTML"]],template:function(e,n){if(e&1&&Dt(0,Rn,1,5,"div",0)(1,Pn,2,3,"mat-icon",1),e&2){let a;Mt((a=n.sanitizedSvg())?0:1,a)}},dependencies:[Ge],styles:[`[_nghost-%COMP%]{display:inline-flex;align-items:center;justify-content:center}[_nghost-%COMP%]   mat-icon[_ngcontent-%COMP%]{display:flex;flex:1}.plugin-svg-icon[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center}.plugin-svg-icon[_ngcontent-%COMP%]     svg{width:100%;height:100%;fill:currentColor}
/*# sourceMappingURL=plugin-icon.component-ATSRPLOY.css.map */`],changeDetection:0})}}return i})()});export{Dr as a,In as b,Rr as c,An as d,jn as e,Ki as f,Qn as g,$i as h,ii as i,ni as j,_a as k,tn as l,io as m,Fn as n,po as o,Bn as p,qa as q,sn as r,Cr as s,Er as t,xn as u};
//# sourceMappingURL=chunk-N2XW2TO3.js.map
