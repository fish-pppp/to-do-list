import{i as o,j as m}from"./chunk-ADFGZN7Y.js";import{Ea as i,H as t,bb as p,ie as n}from"./chunk-BYZBW3B6.js";import{e}from"./chunk-PE6UJDCZ.js";var f,s=e(()=>{"use strict";n();p();m();f=()=>{let r=i(o);return t(()=>!r.isApplyingRemoteOps())}});export{f as a,s as b};
//# sourceMappingURL=chunk-OFNHKTTA.js.map
